$(document).ready(function(){ 
	

	//方法：获取分辨率  
	function getResolution(PageSize){
		var arr = PageSize.split("*");
		var width = 1280;
		var height = 720;
		var w = 640;
		var h = 530;
		if(arr[0]>=0){
			w = arr[0];
		}	
		if(arr[1]>=0){
			h = arr[1];
		}	
		$("body").css("width",w).css("height",h);
		var imgw = $(".advert img").width();
		var imgh = $(".advert img").height();
		var w_img = w/width*imgw;
		var h_img = (w_img*imgh)/imgw;
		$(".advert img").css("width",w_img).css("height",h_img);
		
		
	}
	var PageSize=Authentication.CTCGetConfig("PageSize");	
	//var PageSize = "640*530";
	getResolution(PageSize);
	
	
	
});